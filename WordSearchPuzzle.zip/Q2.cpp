#include<iostream>
#include<fstream>
#include<cstdlib>
#include<cstring>
#include<string>
#include<windows.h>
using namespace std; 
#define matrixRows 18
#define matrixCols 19

//                                 FUNCTION DEFINITIONS                                               //
////////////////////////////////////////////////////////////////////////////////////////////////////////


bool RightToLeftCheck( string list , char WordGrid[][matrixCols] , ofstream& output);                
bool LeftToRightCheck(string list , char WordGrid[][matrixCols] , ofstream& output);
bool TopToBottomCheck( string list , char WordGrid[][matrixCols] , ofstream& output);
bool BottomToTopCheck(string list , char WordGrid[][matrixCols] , ofstream& output);
bool RightDiagonalCheck( string list , char WordGrid[][matrixCols] , ofstream& output);
bool LeftDiagonalCheck(string list , char WordGrid[][matrixCols] , ofstream& output);

//                                END OF FUNCTION DEFINITIONS                                        //
///////////////////////////////////////////////////////////////////////////////////////////////////////

int main(){
	
		bool check = 0; //used in while loop ( explanation in the loop)
		bool WordFound = 0; //used in while loop ( explanation in the loop)
	
		char Grid[matrixRows][matrixCols]; //grid initialized with 18 rows and 19 cols defined
		
		ifstream FileOpen("Grid.txt"); //file is read from the same loacation as cpp
		ofstream FileWrite("outputforq2.txt"); //new file created to be written to
		 		 		 
		 for( int i = 0 ; i < matrixRows ; i++)
			{
				for(int j = 0 ; j < matrixCols ; j++)
				{
					FileOpen>>Grid[i][j] ; // characters from file are inputted into the matrix
				}
			}
			
		FileOpen.close();	
////////////////////////////////////////////////////////////////////////////////////////////////////////////////		
		 
			for(int i = 0 ; i < matrixRows ; i++)
            {
				for(int j = 0 ; j < matrixCols ; j++)
            	{
                	cout<<Grid[i][j]<<" "; // the grid with inputted characters is displayed on console
                	Sleep(3);
        		}
        		cout<<endl;
        	}
        	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

	int numberOfWords = 0;
	cout<<endl<<endl;
    cout<<"********************************************************************************"<<endl;
    Sleep(600);
    
    cout<<"              Enter How Many Words You are going to be searching                "<<endl;
    Sleep(600);
	cout<<"********************************************************************************"<<endl;		
	Sleep(600);
	cout<<" -------------------------->";
	Sleep(600);
	cin>>numberOfWords; // the number of words to be searched for is asked from the user
	
	string ListofWords[numberOfWords];
	
	for(int i = 0 ; i < numberOfWords ; i++)
	{
		cin>>ListofWords[i];	// input for the words to be searched for is taken in the ListofWords string
	}		

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////		        	

    int counter = 0;    	// to search for all words and exit once all words are searched
	while( counter < numberOfWords){
		
		check = false; // checks if the word is not found in the grid and used in printing "not found",set to false so it resets everytime for new word
		//word found is a boolean and if its true it means word was found in the grid 
		
		WordFound =  LeftToRightCheck( ListofWords[counter] , Grid , FileWrite);
		if(WordFound != false )
		{
			check = true;
		}
		
		WordFound =  RightToLeftCheck( ListofWords[counter] , Grid , FileWrite);
		if(WordFound != false )
		{
			check = true;
		}
		
		WordFound = TopToBottomCheck( ListofWords[counter] , Grid , FileWrite);
		if(WordFound != false )
		{
			check = true;
		}
		
		WordFound = BottomToTopCheck( ListofWords[counter] , Grid , FileWrite);
		if(WordFound != false )
		{
			check = true;
		}
		
		WordFound = LeftDiagonalCheck( ListofWords[counter] , Grid , FileWrite);
		if(WordFound != false )
		{
			check = true;
		}
		
		WordFound = RightDiagonalCheck( ListofWords[counter] , Grid , FileWrite);
		if(WordFound != false )
		{
			check = true;
		}		
	
		if(check != true && WordFound  != true ) // if word is not found in the grid
		{
			cout<<endl;
			FileWrite<<ListofWords[counter]<<" Word Not Found "<<" "; // written in the new file we created
			cout<<ListofWords[counter]<<" Word Not Found "<<" "; //output on console
		}
	
	
	    counter++; // to loop the process for the next word
	}
	
	FileWrite.close();  //output file closed
	return 0;
	
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

bool RightToLeftCheck(string list , char WordGrid[][matrixCols] , ofstream& output){
	
	bool match = false;  // to check if word matches/found
	int wordlength = list.length(); // built in function to calculate length of the string
	
	for(int i = 0 ; i < matrixRows ; i++ ) //grid searching
	{
		for(int j = matrixCols - 1 ; j >= 0 ; j--)  //grid searching
		{
			if(WordGrid[i][j] == list[0]) // if first character matches
			{
				for(int x = 1 ; x < wordlength ; x++) //to check for remaining characters
				{
					if(WordGrid[i][j-x] != list[x]) //decreasing collumn number since we are comparing backward horizontally
					{
						match = false;
						break;	//jumps out of loop if a character doesnt matches
					}
					else
					{
						match = true;
					}
				}
				
				if(match != false) // if word matches then print on console and in the created file
				{
					output << endl << list << " FROM (" << i << ", " << j << ") TO (" << i << ", " << j - wordlength + 1 << ") \n";
					cout << endl << list << " FROM (" << i << ", " << j << ") TO (" << i << ", " << j - wordlength + 1 << ") \n";	
					return match;
				}
			}
		}
	}
	
	return match;
}
        	
bool LeftToRightCheck( string list , char WordGrid[][matrixCols] , ofstream& output){
	
	bool match = false; //already explained
	int wordlength = list.length(); //already explained
	
	for(int i = 0 ; i < matrixRows ; i++) 
	{
		for(int j = 0 ; j < matrixCols ; j++)
		{                                        //grid traversing ( done in programming fundamentals lab aswell )
			if(WordGrid[i][j] == list[0])
			{
				for(int x = 1 ; x < wordlength ; x++)
				{
					if(WordGrid[i][j+x] != list[x]) //collumn number being added each time since this horizontal checking
					{
						match = false;
						break;
					}
					else
					{
						match = true;
					}
				}
				
				if(match != false) //explained
				{
					output << endl << list << " FROM (" << i << ", " << j << ") TO (" << i << ", " << j + wordlength - 1 << ") \n";	
					cout << endl << list << " FROM (" << i << ", " << j << ") TO (" << i << ", " << j + wordlength - 1 << ") \n";
					return match;
				}
			}
		}
	}
	
	return match;
	
	
	
}    

bool TopToBottomCheck( string list , char WordGrid[][matrixCols] , ofstream& output){
	
	bool match = false;
	int wordlength = list.length();
	
	for(int i = 0 ; i < matrixCols ; i++)
	{
		for(int j = 0 ; j < matrixRows ; j++)
		{
			if(WordGrid[i][j] == list[0])
			{
				for(int x = 1 ; x < wordlength ; x++)
				{
					if(WordGrid[i + x][j] != list[x])  // row number being increased since this is checking vertically forward
					{
						match = false;
						break;
					}
					else
					{
						match = true;
					}
				}
				
				if(match != false)
				{
					output << endl << list << " FROM (" << i << ", " << j << ") TO (" << i + wordlength - 1 << ", " << j << ")\n";	
					cout << endl << list << " FROM (" << i << ", " << j << ") TO (" << i + wordlength - 1 << ", " << j << ")\n";
					return match;
				}
			}
		}
	}
	
	return match;
}

bool BottomToTopCheck( string list , char WordGrid[][matrixCols] , ofstream& output){
	
 bool match = false;
 int wordlength = list.length();
	
	for(int i = 0 ; i < matrixCols ; i++)
	{
		for(int j = matrixRows - 1 ; j >= 0 ; j--)
		{
			if(WordGrid[i][j] == list[0])
			{
				for(int x = 1 ; x < wordlength ; x++)
				{
					if(WordGrid[i - x][j] != list[x]) //row number being decreased since this is checking vertically backward now
					{
						match = false;
						break;
					}
					else
					{
						match = true;
					}
				}
				
				if(match != false)
				{
					output << endl << list << " FROM (" << i << ", " << j << ") TO (" << i - wordlength + 1 << ", " << j << ")\n";	
					cout << endl << list << " FROM (" << i << ", " << j << ") TO (" << i - wordlength + 1 << ", " << j << ")\n";
					return match;
				}
			}
		}
	}
	
	return match;
	
}

bool RightDiagonalCheck( string list , char WordGrid[][matrixCols] , ofstream& output){
	
	bool match = false;
	int wordlength = list.length();
	
	for(int i = 0 ; i < matrixCols ; i++)
	{
		for(int j = 0 ; j < matrixRows ; j++)
		{
			if(WordGrid[i][j] == list[0])
			{
				for(int x = 1 ; x < wordlength ; x++)
				{
					if(WordGrid[i + x][j + x] != list[x]) // for forward diagonal checking both the row and collumn is incremented
					{
						match = false;
						break;
					}
					else
					{
						match = true;
					}
				}
				
				if(match != false)
				{
					output << endl << list << " FROM (" << i << ", " << j << ") TO (" << i + wordlength - 1 << ", " << j + wordlength - 1 << ")\n";	
					cout << endl << list << " FROM (" << i << ", " << j << ") TO (" << i + wordlength - 1 << ", " << j + wordlength - 1 << ")\n";
					return match;
				}
			}
		}
	}
	
	return match;
	
}

bool LeftDiagonalCheck( string list , char WordGrid[][matrixCols] , ofstream& output){
	
	bool match = false;
	int wordlength = list.length();
	
	for(int i = 0 ; i < matrixCols ; i++)
	{
		for(int j = 0 ; j < matrixRows ; j++)
		{
			if(WordGrid[i][j] == list[0])
			{
				for(int x = 1 ; x < wordlength ; x++)
				{
					if(WordGrid[i - x][j - x] != list[x])  //// for backward diagonal checking both the row and collumn is decremented
					{
						match = false;
						break;
					}
					else
					{
						match = true;
					}
				}
				
				if(match != false)
				{
					output << endl << list << " FROM (" << i << ", " << j << ") TO (" << i - wordlength + 1 << ", " << j - wordlength + 1 << ")\n";	
					cout << endl << list << " FROM (" << i << ", " << j << ") TO (" << i - wordlength + 1 << ", " << j - wordlength + 1 << ")\n";
					return match;
				}
			}
		}
	}
	
	return match;
	
}



