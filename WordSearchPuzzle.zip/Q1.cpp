#include<iostream>
#include<fstream>
#include<cstdlib>
#include<cstring>
#include<string>
#include<windows.h>
using namespace std;


//                                 FUNCTION DEFINITIONS                                               //
////////////////////////////////////////////////////////////////////////////////////////////////////////

void Initiate();
bool Diagonal(string inputword , char matrix[][10]);
bool Horizontal(string inputword , char matrix[][10]);
bool Vertical(string inputword , char matrix[][10]);


//                                END OF FUNCTION DEFINITIONS                                        //
///////////////////////////////////////////////////////////////////////////////////////////////////////


int main(){
	
	Initiate(); // greets you with a hi 
	char WordGrid[10][10]; 
	int count = 0; // for counting number of words
	string wordInput[15]; 
	string sorting; // to store temporarily sorted words in descending order
	ifstream FileOpen("inputforq1.txt"); // reads words from file named input.txt
	ofstream FileWrite("outputforq1.txt"); // creates a new file to store the grid
	
/////////////////////////////////////////////////////////////////////////////////////

	int loop = 0; 
	while(!FileOpen.eof())
	{
		FileOpen >> wordInput[loop];
		loop++; // adding to loop index
		count++; // adding to the count of words taken as input from file
	}

	
	cout<<"TOTAL WORD COUNT IS : "<<"  "<<count<<endl<<endl; //displays total words read from file

/////////////////////////////////////////////////////////////////////////////////////
	
	cout<<" I HAVE READ THE FOLLOWING WORDS FROM FILE : "<<endl<<endl;
	
	for(int i = 0 ; i<= count ; i++)
	{
		cout<<wordInput[i]<<" ";
	}
	cout<<endl<<endl;
	
	
	for (int i = 0; i < 10; i++)
	{
		for (int j = 0; j < 10; j++)
		{
			WordGrid[i][j] = ' ';	// grid is initialized and all values are set to empty
		}
	}
	
//////////////////////////////////////////////////////////////////////////////////////	
	
	cout<<" WORDS SORTED : "<<endl<<endl;
	

	for(int i = 0 ; i < count - 1 ; i++)
	{
		for(int j = i + 1 ; j < count ; j++)
		{
			int stringonelength = wordInput[i].length();
			int stringtwolength = wordInput[j].length();
			
			if(stringonelength < stringtwolength)   	
			{
				sorting = wordInput[i];      // sorting in descending order as larger words are placed first in the grid making it easier for the smaller words to fill the remaining place            
				wordInput[i] = wordInput[j];
				wordInput[j] = sorting;    
			}
		}
	}
	
	for(int i = 0 ; i <= count ; i++)
	{
		cout<<wordInput[i]<<" ";
	}
	cout<<endl<<endl;    // the words which are read from file are displayed in sorted order

//////////////////////////////////////////////////////////////////////////////////////	
	
	FileOpen.close();
	
	int placeword = 0;  // this decides if the function of diagonal , vertical or horizontal is going to be called
	int i = 0; //to control loop index
	
	while(i < count )   // so all words can be placed 
	{
		placeword = rand() % 3;     // %3 since we have 3 functions and we want the words to be placed randomly using it
		if(placeword == 2)
		{
			if(Diagonal(wordInput[i] , WordGrid) == 1) // true if there is enough space to store diagonally
			{
				i++; // index is incremented and next word is brought up to be placed
			}
		}
		if(placeword == 1)
		{
			if(Horizontal(wordInput[i] , WordGrid) == 1) //true if there is enough space to store horizontally
			{
				i++;
			}
		}
		if(placeword == 0)
		{
			if(Vertical(wordInput[i] , WordGrid) == 1)  //true if there is enough space to store vertically
			{
				i++;
			}
		}
	}
	
//////////////////////////////////////////////////////////////////////////////////////	
	
	for(int i = 0 ; i < 10 ; i++)
	{	
		for(int j = 0 ; j < 10 ; j++)
		{
			if(WordGrid[i][j] == ' ')  // if grid is empty 
			{
			 	do{
						WordGrid[i][j] = rand();  // fill grid with a random alphabet
			      }while(!(WordGrid[i][j]>=97 && WordGrid[i][j]<=122));
			}
		}
	}
	
//////////////////////////////////////////////////////////////////////////////////////	
	
	for(int i = 0 ; i < 10 ; i++)
	{
		for(int j = 0 ; j < 10 ; j++)
		{
			FileWrite<<WordGrid[i][j]<<" ";  // write to the file we created
			cout<<WordGrid[i][j]<<" "; // display on console screen
		}
		cout<<endl;
		FileWrite<<endl;
	}
	
	FileWrite.close();    
//////////////////////////////////////////////////////////////////////////////////////	
	
	return 0;
	
}
	
void Initiate(){

    cout<<"********************************************************************************"<<endl;
    cout<<"*                                                                              *"<<endl;
    cout<<"*                                                                              *"<<endl;
    cout<<"*                                                                              *"<<endl;
    cout<<"*                                                                              *"<<endl;
  	cout<<"*                          *      *   *******                                  *"<<endl;
    cout<<"*                          *      *      *                                     *"<<endl;
    cout<<"*                          *      *      *                                     *"<<endl;
    cout<<"*                          ********      *                                     *"<<endl;
    cout<<"*                          *      *      *                                     *"<<endl;
    cout<<"*                          *      *   *******                                  *"<<endl;
    cout<<"*                                                                              *"<<endl;
    cout<<"*                                                                              *"<<endl;
    cout<<"*                          Press Enter to Proceed                              *"<<endl;
    cout<<"*                                                                              *"<<endl;
    cout<<"*                                                                              *"<<endl;
    cout<<"*                                                                              *"<<endl;
    cout<<"*                                                                              *"<<endl;
    cout<<"*                                                      By: Sohaib              *"<<endl;
    cout<<"********************************************************************************"<<endl;
  	
    cin.get();
	system("cls");
}
		
bool Diagonal(string inputword , char matrix[][10]){
	
	int MatrixRow , MatrixCol;
	int matrixbounds = (11 - inputword.length());    // calculates the bounds/limit for words
	MatrixRow = rand() % matrixbounds;
	MatrixCol = rand() % matrixbounds;
	bool occupied = 0; // space occupied or not
	int wordlength = inputword.length();
	
	for( int i = MatrixCol , j = 0 , x = MatrixRow ; j < wordlength ; i++ , j++ , x++) // checks if the word can be placed within bounds and there is enough space
	{
		if(inputword[j] == matrix[x][i]) //checking overlapping
		{
			occupied = 1;  // can place word
		}
		else if((matrix[x][i] == ' '))
		{
			occupied = 1;  // can place word
		}
		else
		{
			occupied = 0; // cannot place word as space not available or out of bounds
			break;
		}
	}
	
	if(occupied != 0)
	{
		int i = 0 ;
		while( inputword[i] != '\0')
		{
			matrix[MatrixRow][MatrixCol] = inputword[i];
			i++;
			MatrixRow++;   // cols and rows are incremented since word is being placed diagonally
			MatrixCol++;	
		}
	}
	
	return occupied;
}	
	
bool Horizontal(string inputword , char matrix[][10]){
	
	int MatrixRow , MatrixCol;
	int matrixbounds = (11 - inputword.length()); // checking if word is in the bounds of the matrix
	
	MatrixCol = rand() % matrixbounds; // so word is in bounds
	MatrixRow = rand() % 10;   // location on matrix is randomly selected
	
	bool occupied = 0; // already explained
	int wordlength = inputword.length();
	
	
	for( int i = MatrixCol , j = 0 ; j < wordlength ; i++ , j++ )
	{
		if(inputword[j] == matrix[MatrixRow][i]) 
		{
			occupied = 1;
		}
		else if(matrix[MatrixRow][i] == ' ')
		{
			occupied = 1;
		}
		else
		{
			occupied = 0;
			break;
		}
	}
	
	if(occupied != 0)
	{
		int i = 0 ;
		while( inputword[i] != '\0')
		{
			matrix[MatrixRow][MatrixCol] = inputword[i];
			i++;
			MatrixCol++;	// only col increases since horizontally ------
		}
	}
	
	return occupied;
}	
	
bool Vertical(string inputword , char matrix[][10]){
	
	int MatrixRow , MatrixCol;
	int matrixbounds = (11 - inputword.length());
	
	MatrixCol = rand() % 10; // location of collumn is randomly generated
	MatrixRow = rand() % matrixbounds; // to ensure it is in bounds vertically
	
	int wordlength = inputword.length();
	bool occupied = 0;
	
	for( int i = MatrixRow , j = 0 ; j < wordlength ; i++ , j++ )
	{
		if(inputword[j] == matrix[i][MatrixCol])
		{
			occupied = 1;

		}
		else if(matrix[i][MatrixCol] == ' ')
		{
			occupied = 1;
		}
		else
		{
			occupied = 0;
			break;
		}
	}
	
	if(occupied != 0)
	{
		int i = 0 ;
		while( inputword[i] != '\0')
		{
			matrix[MatrixRow][MatrixCol] = inputword[i];
			i++;
			MatrixRow++;	// only row increases since vertically |
		}
	}
	
	return occupied;
	
}	
	
	
	
	
	
	






	
		
		
	
	
	


